/**
 * Created by Administrator on 2017/4/12.
 */
(function(){
    var html = document.documentElement;
    var hWidth = html.clientWidth;
    html.style.fontSize = hWidth/15 + 'px';
})();